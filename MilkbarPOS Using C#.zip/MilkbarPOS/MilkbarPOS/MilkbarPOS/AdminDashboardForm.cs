﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MilkbarPOS
{
    public partial class AdminDashboardForm : Form
    {
        public AdminDashboardForm()
        {
            InitializeComponent();
        }

        private void btnManageInventory_Click(object sender, EventArgs e)
        {

            InventoryManagementForm imf = new InventoryManagementForm();
            imf.Show();  // Open Inventory Management Form
            this.Hide(); // Hide Admin Dashboard
        }

        private void btnGenerateReport_Click(object sender, EventArgs e)
        {
            ReportForm rf = new ReportForm();
            rf.Show();  // Open Sales Report Form
            this.Hide(); // Hide Admin Dashboard
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {

            this.Close(); // Close Admin Dashboard
            LoginForm login = new LoginForm(); // Reopen the LoginForm
            login.Show();
        }
    }
}
