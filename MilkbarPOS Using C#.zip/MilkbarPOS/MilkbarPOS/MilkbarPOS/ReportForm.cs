﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MilkbarPOS
{
    public partial class ReportForm : Form
    {

        // Connecting the database
        private SqlConnection conn = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=MilkbarPOS;Integrated Security=True");
        public ReportForm()
        {
            InitializeComponent();
            LoadCategories();
        }

        private void LoadCategories()
        {
            try
            {
                // Open database connection
                conn.Open();

                // SQL query to fetch distinct product categories
                SqlCommand cmd = new SqlCommand("SELECT DISTINCT Category FROM Products", conn);
                SqlDataReader reader = cmd.ExecuteReader();

                cmbCategory.Items.Clear(); // Clear existing items in ComboBox

                while (reader.Read())
                {
                    cmbCategory.Items.Add(reader["Category"].ToString());
                }

                reader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                conn.Close(); // Ensure connection is closed
            }
        }

        private void btnGenerateReport_Click(object sender, EventArgs e)
        {

            try
            {
                DateTime startDate = dtpStartDate.Value;
                DateTime endDate = dtpEndDate.Value;
                string category = cmbCategory.SelectedItem?.ToString();

                // Open database connection
                conn.Open();

                // SQL query to fetch sales data based on selected filters
                string query = "SELECT p.ProductName, p.Category, SUM(td.Quantity) AS Quantity, SUM(td.SubTotal) AS TotalSales " +
                               "FROM TransactionDetails td " +
                               "JOIN Products p ON td.ProductID = p.ProductID " + // Join with Products table to get ProductName and Category
                               "JOIN Transactions t ON td.TransactionID = t.TransactionID " + // Join with Transactions table for Sale Date
                               "WHERE t.TransactionDate BETWEEN @startDate AND @endDate ";

                // Add category filter if selected
                if (!string.IsNullOrEmpty(category))
                {
                    query += "AND p.Category = @category ";
                }

                query += "GROUP BY p.ProductName, p.Category";

                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@startDate", startDate);
                cmd.Parameters.AddWithValue("@endDate", endDate);

                // Add category parameter if needed
                if (!string.IsNullOrEmpty(category))
                {
                    cmd.Parameters.AddWithValue("@category", category);
                }

                SqlDataReader reader = cmd.ExecuteReader();
                dataGridReport.Rows.Clear();

                while (reader.Read())
                {
                    dataGridReport.Rows.Add(reader["ProductName"], reader["Category"], reader["Quantity"], reader["TotalSales"]);
                }

                reader.Close();
            }
            catch (Exception ex)
            {
                lblReportStatus.Text = "Error: " + ex.Message;
                lblReportStatus.ForeColor = Color.Red;
            }
            finally
            {
                conn.Close(); // Ensure connection is closed
            }
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            this.Close(); // Close Admin Dashboard
            LoginForm login = new LoginForm(); // Reopen the LoginForm
            login.Show();
        }
    }


}
