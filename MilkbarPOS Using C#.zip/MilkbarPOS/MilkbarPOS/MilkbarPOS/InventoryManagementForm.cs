﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MilkbarPOS
{
    public partial class InventoryManagementForm : Form
    {
        // Connecting to the database
        private SqlConnection conn = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=MilkbarPOS;Integrated Security=True");

        public InventoryManagementForm()
        {
            InitializeComponent();
        }

        private void LoadProducts()
        {

            try
            {
                // Open database connection
                conn.Open();

                // SQL query to fetch products
                SqlCommand cmd = new SqlCommand("SELECT ProductID, ProductName, Category, Price, Stock FROM Products", conn);
                SqlDataReader reader = cmd.ExecuteReader();

                // Clear existing rows in DataGridView
                dataGridProducts.Rows.Clear();

                // Add each product as a new row in DataGridView
                while (reader.Read())
                {
                    dataGridProducts.Rows.Add(reader["ProductID"], reader["ProductName"], reader["Category"], reader["Price"], reader["Stock"]);
                }

                reader.Close(); // Close the reader after data fetch
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                conn.Close(); // Ensure connection is closed
            }
        }


        private void InventoryManagementForm_Load(object sender, EventArgs e)
        {
            LoadProducts();
        }

        private void dataGridProducts_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridProducts.SelectedRows.Count > 0)
            {
                // Get the selected row
                DataGridViewRow selectedRow = dataGridProducts.SelectedRows[0];

                // Populate the TextBoxes with the selected row's data
                txtProductName.Text = selectedRow.Cells["ProductName"].Value.ToString();
                txtCategory.Text = selectedRow.Cells["Category"].Value.ToString();
                txtPrice.Text = selectedRow.Cells["Price"].Value.ToString();
                txtStock.Text = selectedRow.Cells["Stock"].Value.ToString();
            }
        }

        private void btnAddProduct_Click(object sender, EventArgs e)
        {

            // Validate if all required fields are entered
            if (string.IsNullOrEmpty(txtProductName.Text) || string.IsNullOrEmpty(txtCategory.Text) || string.IsNullOrEmpty(txtPrice.Text) || string.IsNullOrEmpty(txtStock.Text))
            {
                lblStatusMessage.Text = "Please fill in all fields!";
                lblStatusMessage.ForeColor = Color.Red;
                return; // Stop the operation if any field is empty
            }

            try
            {
                // Ensure the connection is opened and closed automatically using a 'using' block
                using (SqlConnection conn = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=MilkbarPOS;Integrated Security=True"))
                {
                    conn.Open();  // Open the connection to the database

                    SqlCommand cmd = new SqlCommand("INSERT INTO Products (ProductName, Category, Price, Stock) VALUES (@name, @category, @price, @stock)", conn);
                    cmd.Parameters.AddWithValue("@name", txtProductName.Text);
                    cmd.Parameters.AddWithValue("@category", txtCategory.Text);
                    cmd.Parameters.AddWithValue("@price", decimal.Parse(txtPrice.Text));
                    cmd.Parameters.AddWithValue("@stock", int.Parse(txtStock.Text));

                    cmd.ExecuteNonQuery();  // Execute the insert query

                    lblStatusMessage.Text = "Product added successfully!";
                    lblStatusMessage.ForeColor = Color.Green;

                    LoadProducts();  // Reload the product list after adding a new product
                } // Connection is automatically closed at the end of the using block
            }
            catch (Exception ex)
            {
                lblStatusMessage.Text = "Error: " + ex.Message;
                lblStatusMessage.ForeColor = Color.Red; // Error message color
            }
        }

        private void btnUpdateProduct_Click(object sender, EventArgs e)
        {

            // Validate if all required fields are entered
            if (string.IsNullOrEmpty(txtProductName.Text) || string.IsNullOrEmpty(txtCategory.Text) || string.IsNullOrEmpty(txtPrice.Text) || string.IsNullOrEmpty(txtStock.Text))
            {
                lblStatusMessage.Text = "Please fill in all fields!";
                lblStatusMessage.ForeColor = Color.Red;
                return; // Stop the operation if any field is empty
            }

            if (dataGridProducts.SelectedRows.Count == 0)
            {
                lblStatusMessage.Text = "Please select a product to update \nby pressing >";
                lblStatusMessage.ForeColor = Color.Red;
                return;
            }

            try
            {
                int selectedProductId = Convert.ToInt32(dataGridProducts.SelectedRows[0].Cells["ProductID"].Value);  // Get ProductID from DataGridView

                using (SqlConnection conn = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=MilkbarPOS;Integrated Security=True"))
                {
                    conn.Open();  // Open connection
                    SqlCommand cmd = new SqlCommand("UPDATE Products SET ProductName = @name, Category = @category, Price = @price, Stock = @stock WHERE ProductID = @productId", conn);
                    cmd.Parameters.AddWithValue("@productId", selectedProductId);
                    cmd.Parameters.AddWithValue("@name", txtProductName.Text);
                    cmd.Parameters.AddWithValue("@category", txtCategory.Text);
                    cmd.Parameters.AddWithValue("@price", decimal.Parse(txtPrice.Text));
                    cmd.Parameters.AddWithValue("@stock", int.Parse(txtStock.Text));

                    cmd.ExecuteNonQuery();  // Execute the update query
                    lblStatusMessage.Text = "Product updated successfully!";
                    lblStatusMessage.ForeColor = Color.Green; // Success message color

                    LoadProducts();  // Reload the product list after updating
                }
            }
            catch (Exception ex)
            {
                lblStatusMessage.Text = "Error: " + ex.Message;
                lblStatusMessage.ForeColor = Color.Red; // Error message color
            }
        }

        private void btnDeleteProduct_Click(object sender, EventArgs e)
        {

            if (dataGridProducts.SelectedRows.Count == 0)
            {
                lblStatusMessage.Text = "Please select a product to remove by pressing >";
                lblStatusMessage.ForeColor = Color.Red;
                return;
            }

            try
            {
                int selectedProductId = Convert.ToInt32(dataGridProducts.SelectedRows[0].Cells["ProductID"].Value);

                using (SqlConnection conn = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=MilkbarPOS;Integrated Security=True"))
                {
                    conn.Open();

                    // Update the stock to 0 instead of deleting
                    SqlCommand cmd = new SqlCommand("UPDATE Products SET Stock = 0 WHERE ProductID = @productId", conn);
                    cmd.Parameters.AddWithValue("@productId", selectedProductId)    ;
                    cmd.ExecuteNonQuery();

                    lblStatusMessage.Text = "Product marked as unavailable (stock set to 0).";
                    lblStatusMessage.ForeColor = Color.Green;

                    LoadProducts();  // Refresh product list
                }
            }
            catch (Exception ex)
            {
                lblStatusMessage.Text = "Error: " + ex.Message;
                lblStatusMessage.ForeColor = Color.Red;
            }
        }


        private void btnLogout_Click(object sender, EventArgs e)
        {
            this.Close(); // Close Admin Dashboard
            LoginForm login = new LoginForm(); // Reopen the LoginForm
            login.Show();
        }
    }
}
