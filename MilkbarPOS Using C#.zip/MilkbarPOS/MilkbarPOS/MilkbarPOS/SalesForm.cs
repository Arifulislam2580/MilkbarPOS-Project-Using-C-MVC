﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace MilkbarPOS
{
    public partial class SalesForm : Form
    {
        // Database Connection
        private SqlConnection conn = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=MilkbarPOS;Integrated Security=True");

        public SalesForm()
        {
            InitializeComponent();
        }

        //  Load Products into ComboBox (called on form load)
        private void LoadProducts()
        {
            try
            {
                conn.Open(); // Open connection to the database

                SqlCommand cmd = new SqlCommand("SELECT ProductID, ProductName FROM Products", conn);
                SqlDataReader reader = cmd.ExecuteReader();

                cmbProducts.Items.Clear();  // Clear any existing items in the ComboBox

                // Loop through the products in the database and add them to the ComboBox
                while (reader.Read())
                {
                    cmbProducts.Items.Add(new
                    {
                        Text = reader["ProductName"].ToString(),
                        Value = reader["ProductID"]
                    });
                }

                // Set the ComboBox to display the product name and use the ProductID for the value
                cmbProducts.DisplayMember = "Text";
                cmbProducts.ValueMember = "Value";

                reader.Close(); // Close the data reader
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                conn.Close();  // Ensure the connection is always closed
            }
        }

        // Call LoadProducts() when the SalesForm is loaded
        private void SalesForm_Load(object sender, EventArgs e)
        {
            LoadProducts();  // Load the products into the ComboBox

            cmbPaymentMethod.Items.Clear();
            // Add payment methods to the ComboBox
            cmbPaymentMethod.Items.Add("Cash");
            cmbPaymentMethod.Items.Add("Card");
            cmbPaymentMethod.SelectedIndex = 0;
        }

        // Add "Add to Cart" functionality
        private void btnAddToCart_Click(object sender, EventArgs e)
        {

            if (cmbProducts.SelectedItem == null)
            {
                MessageBox.Show("Please select a product.");
                return;
            }

            if (string.IsNullOrEmpty(txtQuantity.Text) || !int.TryParse(txtQuantity.Text, out int quantity) || quantity <= 0)
            {
                MessageBox.Show("Please enter a valid quantity.");
                return;
            }

            var selectedProduct = cmbProducts.SelectedItem as dynamic;
            int productId = selectedProduct.Value;
            string productName = selectedProduct.Text;

            // Get current stock
            int stock = GetProductStock(productId);

            // Check if product is out of stock
            if (stock <= 0)
            {
                MessageBox.Show("Product is out of stock!");
                return;
            }

            // Check if requested quantity exceeds stock
            if (quantity > stock)
            {
                MessageBox.Show($"Only {stock} items available in stock.");
                return;
            }

            // Get price
            decimal productPrice = GetProductPrice(productId);
            decimal subtotal = productPrice * quantity;

            // Add to cart with stock column included
            dataGridCart.Rows.Add(productId, productName, quantity, productPrice, subtotal, stock);

            UpdateTotalPrice();
            btnCompleteSale.Enabled = dataGridCart.Rows.Count > 0;
        }

        private int GetProductStock(int productId)
        {
            int stock = 0;
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("SELECT Stock FROM Products WHERE ProductID = @productId", conn);
                cmd.Parameters.AddWithValue("@productId", productId);

                var result = cmd.ExecuteScalar();
                if (result != null)
                {
                    stock = Convert.ToInt32(result);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error fetching stock: " + ex.Message);
            }
            finally
            {
                conn.Close();
            }

            return stock;
        }


        // Fetch product price from database using ProductID
        private decimal GetProductPrice(int productId)
        {
            decimal price = 0;

            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("SELECT Price FROM Products WHERE ProductID = @productId", conn);
                cmd.Parameters.AddWithValue("@productId", productId);

                // Execute the query and get the price
                price = (decimal)cmd.ExecuteScalar();  // ExecuteScalar returns the first column of the first row
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error fetching product price: " + ex.Message);
            }
            finally
            {
                conn.Close();
            }

            return price;
        }

        //Update total price after adding items to cart
        private void UpdateTotalPrice() //done
        {
            decimal totalPrice = 0;

            // Loop through all rows in the DataGridView and sum the subtotals
            foreach (DataGridViewRow row in dataGridCart.Rows)
            {
                totalPrice += Convert.ToDecimal(row.Cells["Subtotal"].Value);  // Column "Subtotal" holds the subtotal for each item
            }

            // Update the total price label to display the total amount
            lblTotalPrice.Text = totalPrice.ToString("C");  // Format as currency (e.g., $48.00)
        }

        private void SaveTransaction()
        {
            decimal totalAmount = 0;

            // Loop through the DataGridView rows to calculate the total amount (sum of all item subtotals)
            foreach (DataGridViewRow row in dataGridCart.Rows)
            {
                totalAmount += Convert.ToDecimal(row.Cells["Subtotal"].Value);  // Column "Subtotal" holds the subtotal for each item
            }

            // Get the payment method selected (Cash or Card)
            string paymentMethod = cmbPaymentMethod.SelectedItem.ToString();

            int transactionId = 0;

            try
            {
                conn.Open();  // Open the database connection

                // Insert the transaction into the `Transactions` table
                SqlCommand cmd = new SqlCommand(
                    "INSERT INTO Transactions (UserID, TransactionDate, TotalAmount, PaymentMethod) OUTPUT INSERTED.TransactionID VALUES (@userId, @transactionDate, @totalAmount, @paymentMethod)", conn);
                cmd.Parameters.AddWithValue("@userId", 1);  // Replace with the actual user ID (cashier or admin)
                cmd.Parameters.AddWithValue("@transactionDate", DateTime.Now);
                cmd.Parameters.AddWithValue("@totalAmount", totalAmount);
                cmd.Parameters.AddWithValue("@paymentMethod", paymentMethod);

                transactionId = (int)cmd.ExecuteScalar();  // Get the inserted TransactionID

                // Insert each product in the cart into the `TransactionDetails` table
                foreach (DataGridViewRow row in dataGridCart.Rows)
                {
                    // Skip the empty "new row" that is automatically added by the DataGridView
                    if (row.IsNewRow) continue;

                    // Get Quantity and Price
                    int quantity = Convert.ToInt32(row.Cells["Quantity"].Value);
                    decimal price = Convert.ToDecimal(row.Cells["PricePerUnit"].Value);

                    // Validate that quantity is greater than 0 before inserting
                    if (quantity <= 0)
                    {
                        MessageBox.Show("Quantity must be greater than 0 for all items.");
                        return; // Stop the process and display error
                    }

                    // Insert into TransactionDetails table (without SubTotal since it's computed)
                    SqlCommand cmdDetails = new SqlCommand(
                        "INSERT INTO TransactionDetails (TransactionID, ProductID, Quantity, PricePerUnit) VALUES (@transactionId, @productId, @quantity, @price)", conn);
                    cmdDetails.Parameters.AddWithValue("@transactionId", transactionId);
                    cmdDetails.Parameters.AddWithValue("@productId", row.Cells["ProductID"].Value);
                    cmdDetails.Parameters.AddWithValue("@quantity", quantity);
                    cmdDetails.Parameters.AddWithValue("@price", price);

                    cmdDetails.ExecuteNonQuery();  // Execute the insert for each item in the cart
                }

                // Update the stock in the Products table after the sale
                foreach (DataGridViewRow row in dataGridCart.Rows)
                {
                    int productId = Convert.ToInt32(row.Cells["ProductID"].Value);  // Get ProductID
                    int quantity = Convert.ToInt32(row.Cells["Quantity"].Value);    // Get Quantity

                    // Update the product stock in the Products table
                    SqlCommand cmdUpdate = new SqlCommand(
                        "UPDATE Products SET Stock = Stock - @quantity WHERE ProductID = @productId", conn);
                    cmdUpdate.Parameters.AddWithValue("@quantity", quantity);
                    cmdUpdate.Parameters.AddWithValue("@productId", productId);

                    cmdUpdate.ExecuteNonQuery();  // Execute the update for stock reduction
                }

                MessageBox.Show("Transaction saved successfully!");  // Notify the user the transaction is complete
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);  // Display any errors that occur
            }
            finally
            {
                conn.Close();  // Always close the connection to the database
            }
        }

        private void btnCompleteSale_Click(object sender, EventArgs e)
        {
            // Check if there are items in the cart
            if (dataGridCart.Rows.Count == 0)
            {
                MessageBox.Show("Please add items to the cart before completing the sale.");
                return;
            }

            // Check if payment method is selected
            if (cmbPaymentMethod.SelectedItem == null)
            {
                MessageBox.Show("Please select a payment method (Cash/Card).");
                return;
            }

            // Validate quantity in cart (skip empty rows)
            foreach (DataGridViewRow row in dataGridCart.Rows)
            {
                // Skip the empty "new row" that is automatically added by the DataGridView
                if (row.IsNewRow) continue;

                // Get the quantity value from the "Quantity" column
                var quantityValue = row.Cells["Quantity"].Value;

                // If quantity is null or less than or equal to 0, show an error and stop the process
                if (quantityValue == null || Convert.ToInt32(quantityValue) <= 0)
                {
                    MessageBox.Show("Quantity must be greater than 0 for all items.");
                    return; // Stop the process and display error
                }
            }

            // Confirm sale completion
            DialogResult result = MessageBox.Show("Are you sure you want to complete this sale?", "Confirm Sale", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                // Save the transaction to the database
                SaveTransaction();

                // Optionally, clear the cart after completing the sale
                dataGridCart.Rows.Clear();
                lblTotalPrice.Text = "$0.00";  // Reset the total
                MessageBox.Show("Sale completed successfully!");
            }
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            this.Close(); // Close Admin Dashboard
            LoginForm login = new LoginForm(); // Reopen the LoginForm
            login.Show();
        }
    }
}
