﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;


namespace MilkbarPOS
{
    public partial class LoginForm : Form
    {
        //Connecting to database
        private SqlConnection conn = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=MilkbarPOS;Integrated Security=True");

        public LoginForm()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text.Trim();

            if (username == "" || password == "")
            {
                lblMessage.Text = "Please enter both username and password.";
                return;
            }

            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("SELECT U.UserID, R.RoleName FROM Users U JOIN Roles R ON U.RoleID = R.RoleID WHERE U.Username = @username AND U.PasswordHash = @password", conn);
                cmd.Parameters.AddWithValue("@username", username);
                cmd.Parameters.AddWithValue("@password", password); // In real apps, hash it

                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    string role = reader["RoleName"].ToString();

                    MessageBox.Show("Login successful! Role: " + role);

                    this.Hide(); // hide the login form

                    if (role == "Cashier")
                    {
                        SalesForm sf = new SalesForm();
                        sf.Show();
                    }
                    else if (role == "Admin")
                    {
                        AdminDashboardForm dashboard = new AdminDashboardForm();
                        dashboard.Show();  // Open Admin Dashboard
                        this.Hide();  // Hide Login Form
                    }
                    else
                    {
                        MessageBox.Show("Unknown role detected.");
                        this.Show();
                    }
                }
                else
                {
                    lblMessage.Text = "Invalid credentials. Try again.";
                }

                reader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                conn.Close();
            }

        }
    }
}
